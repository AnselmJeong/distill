library(testthat)
library(distill)

test_check("distill")
