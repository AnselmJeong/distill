# create_theme works

    v Created CSS file at my-style.css 
    o TODO: Customize it to suit your needs 
    o TODO: Add 'theme: my-style.css' to your site or article YAML
     
    See docs at https://rstudio.github.io/distill/website.html#theming

